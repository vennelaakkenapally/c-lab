#include<stdio.h>
int sample;
int main(void)
{
    printf("%p",&sample);
    return 0;
}

